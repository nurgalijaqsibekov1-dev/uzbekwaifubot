# Uzbek Waifu Game (Node.js)

Telegram bot: `@UzbekWaifuBot`

## Features
- Posts a random anime character after every 50 eligible group messages.
- Users guess the character name to add it to their collection.
- Rarities: Common, Rare, Epic, Legendary.
- `/collection`, `/profile`, `/rank`, `/stats`.
- Admin-only character creation by sending a photo with a caption:
  `/addcharacter Name | Anime | Rarity | aliases`
- `/addhelp` explains character management.
- `/admin` checks whether the current user is an admin.
- SQLite database for characters, collections, counters and active drops.
- Simple HTTP health endpoint at `/health` for hosting platforms.

## Setup locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Put your Telegram token in `BOT_TOKEN`. Keep it secret.
4. Set `ADMIN_IDS` to comma-separated Telegram numeric user IDs.
5. Install dependencies: `npm install`
6. Start: `npm start`

## Character management
Send a character image to the bot in a private chat with this exact caption format:

`/addcharacter Gojo Satoru | Jujutsu Kaisen | Legendary | gojo,satoru`

Rarity must be one of `Common`, `Rare`, `Epic`, `Legendary`.
The photo is stored by Telegram `file_id`, not downloaded to the server.

## Group setup
1. Add the bot to the group.
2. In BotFather, use `/setprivacy`, select the bot, and choose **Disable** so it can count ordinary group messages.
3. Ensure the bot can send messages in the group.
4. The bot posts a new drop after each 50 non-command group messages.

## Docker
Build:
`docker build -t uzbek-waifu-game .`

Run (mount a persistent folder for SQLite):
`docker run -d --name waifu-bot --restart unless-stopped --env-file .env -v waifu-data:/data uzbek-waifu-game`

## Render notes
This project uses Telegram long polling. Use a service type that supports a continuously running process (Background Worker where available), set:
- Build command: `npm install`
- Start command: `npm start`
- Environment variables: `BOT_TOKEN`, `ADMIN_IDS`, `DATABASE_PATH=/data/anime.db`

Attach a persistent disk mounted at `/data` if the Render plan supports it. Without persistent storage, SQLite data may be lost on redeploy/restart.
A free web service may sleep and is not a reliable 24/7 host. If using a Web Service, the included `/health` endpoint binds to `PORT`, but sleep limits still apply.

## Existing Python database
The original Python `anime.db` schema was not included when this Node.js package was generated. This project creates its own SQLite tables. Do not replace your existing database with the new one until you have a backup and have checked/imported the old schema.
