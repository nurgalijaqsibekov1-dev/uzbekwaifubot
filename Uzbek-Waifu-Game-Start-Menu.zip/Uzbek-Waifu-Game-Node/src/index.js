require('dotenv').config();

const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const { init, run, get, all } = require('./db');

const token = process.env.BOT_TOKEN;
if (!token || token.includes('PASTE_YOUR')) {
  console.error('BOT_TOKEN is missing. Set it in your .env or hosting environment.');
  process.exit(1);
}
const adminIds = new Set((process.env.ADMIN_IDS || '').split(',').map(x => x.trim()).filter(Boolean));
const bot = new TelegramBot(token, { polling: true });
const app = express();
const port = Number(process.env.PORT || 3000);

app.get('/', (_req, res) => res.status(200).send('Uzbek Waifu Game bot is running.'));
app.get('/health', (_req, res) => res.status(200).json({ ok: true }));
app.listen(port, '0.0.0.0', () => console.log(`Health server listening on ${port}`));

const rarities = ['Common', 'Rare', 'Epic', 'Legendary'];
const isAdmin = id => adminIds.has(String(id));
const displayName = user => user.username ? `@${user.username}` : (user.first_name || String(user.id));

async function ensureUser(user) {
  await run(
    `INSERT INTO user_stats(user_id, username, first_name) VALUES(?,?,?)
     ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name`,
    [String(user.id), user.username || '', user.first_name || '']
  );
}
async function sendDrop(chatId) {
  const chars = await all('SELECT * FROM characters');
  if (!chars.length) {
    await bot.sendMessage(chatId, 'Hozircha personajlar bazasi bo‘sh. Admin personaj qo‘shishi kerak.');
    return;
  }
  const character = chars[Math.floor(Math.random() * chars.length)];
  await run(
    `INSERT INTO active_drops(chat_id, character_id) VALUES(?,?)
     ON CONFLICT(chat_id) DO UPDATE SET character_id=excluded.character_id, created_at=CURRENT_TIMESTAMP`,
    [String(chatId), character.id]
  );
  await bot.sendPhoto(chatId, character.photo_file_id, {
    caption: `🎴 Yangi personaj chiqdi!\n\nIsmini toping!`
  });
}
async function addToCollection(user, character) {
  const result = await run(
    'INSERT OR IGNORE INTO collections(user_id, character_id) VALUES(?,?)',
    [String(user.id), character.id]
  );
  await run('UPDATE user_stats SET correct_guesses = correct_guesses + 1 WHERE user_id=?', [String(user.id)]);
  return result.changes > 0;
}

bot.onText(/^\/start(?:@\w+)?$/, async msg => {
  await ensureUser(msg.from);
  const name = msg.from.first_name || 'foydalanuvchi';
  const welcome = `🌿 SALOM, ${name.toUpperCase()}!\n\n` +
    `✨ Uzbek Waifu Game botiga xush kelibsiz!\n\n` +
    `🎴 Bu yerda anime personajlarini yig‘ishingiz, ularning noyob kartalarini topishingiz va boshqa o‘yinchilar bilan bellashishingiz mumkin.\n\n` +
    `📌 QANDAY O‘YNALADI?\n` +
    `• Botni guruhingizga qo‘shing.\n` +
    `• Guruhda har 50 ta xabardan keyin yangi waifu/character paydo bo‘ladi.\n` +
    `• Personaj ismini birinchi bo‘lib to‘g‘ri toping va kolleksiyangizga qo‘shing!\n\n` +
    `👇 Kerakli bo‘limni tanlang:`;
  const keyboard = { inline_keyboard: [
    [{ text: '🎴 KOLLEKSIYAM', callback_data: 'menu_collection' }, { text: '👤 PROFIL', callback_data: 'menu_profile' }],
    [{ text: '🏆 REYTING', callback_data: 'menu_rank' }, { text: '📊 STATISTIKA', callback_data: 'menu_stats' }],
    [{ text: '❔ YORDAM', callback_data: 'menu_help' }]
  ]};
  const banner = await get("SELECT value FROM bot_settings WHERE key='start_image'");
  if (banner && banner.value) {
    await bot.sendPhoto(msg.chat.id, banner.value, { caption: welcome, reply_markup: keyboard });
  } else {
    await bot.sendMessage(msg.chat.id, welcome + `\n\n🖼 Start rasmi qo‘yilmagan. Admin /setstartimage orqali rasm o‘rnatsin.`, { reply_markup: keyboard });
  }
});

bot.on('callback_query', async query => {
  try {
    const chatId = query.message.chat.id;
    const user = query.from;
    await ensureUser(user);
    await bot.answerCallbackQuery(query.id);
    switch (query.data) {
      case 'menu_collection': {
        const rows = await all(`SELECT c.name, c.anime, c.rarity FROM collections x JOIN characters c ON c.id=x.character_id WHERE x.user_id=? ORDER BY x.obtained_at DESC`, [String(user.id)]);
        const body = rows.length ? rows.map((r,i) => `${i+1}. ${r.name} — ${r.anime} [${r.rarity}]`).join('\n') : 'Kolleksiyangiz hozircha bo‘sh.';
        await bot.sendMessage(chatId, `🎴 Kolleksiyangiz (${rows.length}):\n${body}`); break;
      }
      case 'menu_profile': {
        const stats = await get('SELECT * FROM user_stats WHERE user_id=?', [String(user.id)]);
        const count = await get('SELECT COUNT(*) AS n FROM collections WHERE user_id=?', [String(user.id)]);
        await bot.sendMessage(chatId, `👤 ${displayName(user)}\nXabarlar: ${stats.messages}\nTo‘g‘ri topishlar: ${stats.correct_guesses}\nKolleksiya: ${count.n} ta`); break;
      }
      case 'menu_rank': {
        const rows = await all(`SELECT u.user_id, u.username, u.first_name, COUNT(c.character_id) AS total FROM user_stats u LEFT JOIN collections c ON c.user_id=u.user_id GROUP BY u.user_id ORDER BY total DESC, u.correct_guesses DESC LIMIT 10`);
        const body = rows.length ? rows.map((r,i) => `${i+1}. ${r.username ? '@'+r.username : (r.first_name || r.user_id)} — ${r.total}`).join('\n') : 'Reyting hozircha bo‘sh.';
        await bot.sendMessage(chatId, `🏆 TOP 10:\n${body}`); break;
      }
      case 'menu_stats': {
        const c = await get('SELECT COUNT(*) AS n FROM characters');
        const u = await get('SELECT COUNT(*) AS n FROM user_stats');
        const owned = await get('SELECT COUNT(*) AS n FROM collections');
        await bot.sendMessage(chatId, `📊 Bot statistikasi\nPersonajlar: ${c.n}\nFoydalanuvchilar: ${u.n}\nKolleksiyadagi kartalar: ${owned.n}`); break;
      }
      case 'menu_help':
        await bot.sendMessage(chatId, `❔ YORDAM\nBotni guruhga qo‘shing. Har 50 ta oddiy xabardan keyin personaj chiqadi. Ismini to‘g‘ri topgan odam uni kolleksiyasiga oladi.\n\n/collection — kolleksiya\n/profile — profil\n/rank — reyting\n/stats — statistika`); break;
    }
  } catch (e) { console.error('menu callback error:', e); }
});

bot.onText(/^\/setstartimage(?:@\w+)?$/, msg => {
  if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, '⛔ Bu buyruq faqat admin uchun.');
  bot.sendMessage(msg.chat.id, '🖼 Start rasmi o‘rnatish uchun menga rasmni caption qismiga /setstartimage deb yozib yuboring.');
});
bot.onText(/^\/myid(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, `Sizning ID: ${msg.from.id}`));
bot.onText(/^\/admin(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, isAdmin(msg.from.id) ? '✅ Siz adminsiz.' : '⛔ Siz admin emassiz.'));
bot.onText(/^\/addhelp(?:@\w+)?$/, msg => {
  if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, '⛔ Bu buyruq faqat admin uchun.');
  bot.sendMessage(msg.chat.id,
    'Personaj qo‘shish:\n1) Botga rasm yuboring.\n2) Caption:\n/addcharacter Ism | Anime | Rarity | alias1,alias2\n\nRarity: Common, Rare, Epic, Legendary\nMisol:\n/addcharacter Gojo Satoru | Jujutsu Kaisen | Legendary | gojo,satoru'
  );
});
bot.on('photo', async msg => {
  try {
    const caption = msg.caption || '';
    if (caption.startsWith('/setstartimage')) {
      if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, '⛔ Faqat admin start rasmini o‘zgartira oladi.');
      const photoId = msg.photo[msg.photo.length - 1].file_id;
      await run(`INSERT INTO bot_settings(key,value) VALUES('start_image',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`, [photoId]);
      return bot.sendMessage(msg.chat.id, '✅ Start rasmi saqlandi! Endi /start yuborib tekshiring.');
    }
    if (!caption.startsWith('/addcharacter')) return;
    if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, '⛔ Faqat admin personaj qo‘sha oladi.');
    const parts = caption.replace(/^\/addcharacter(?:@\w+)?\s*/, '').split('|').map(s => s.trim());
    if (parts.length < 3 || !parts[0] || !parts[1] || !parts[2]) {
      return bot.sendMessage(msg.chat.id, 'Format noto‘g‘ri. /addhelp buyrug‘ini ko‘ring.');
    }
    const [name, anime, rarityRaw, aliases = ''] = parts;
    const rarity = rarities.find(r => r.toLowerCase() === rarityRaw.toLowerCase());
    if (!rarity) return bot.sendMessage(msg.chat.id, `Rarity: ${rarities.join(', ')}`);
    const photoId = msg.photo[msg.photo.length - 1].file_id;
    await run(
      'INSERT INTO characters(name, anime, rarity, aliases, photo_file_id) VALUES(?,?,?,?,?)',
      [name, anime, rarity, aliases, photoId]
    );
    await bot.sendMessage(msg.chat.id, `✅ ${name} (${rarity}) bazaga qo‘shildi!`);
  } catch (e) {
    console.error('add photo error:', e);
    bot.sendMessage(msg.chat.id, 'Personajni qo‘shishda xatolik yuz berdi.');
  }
});
bot.onText(/^\/stats(?:@\w+)?$/, async msg => {
  const c = await get('SELECT COUNT(*) AS n FROM characters');
  const u = await get('SELECT COUNT(*) AS n FROM user_stats');
  const owned = await get('SELECT COUNT(*) AS n FROM collections');
  bot.sendMessage(msg.chat.id, `📊 Bot statistikasi\nPersonajlar: ${c.n}\nFoydalanuvchilar: ${u.n}\nKolleksiyadagi kartalar: ${owned.n}`);
});
bot.onText(/^\/collection(?:@\w+)?$/, async msg => {
  await ensureUser(msg.from);
  const rows = await all(
    `SELECT c.name, c.anime, c.rarity FROM collections x
     JOIN characters c ON c.id=x.character_id WHERE x.user_id=? ORDER BY x.obtained_at DESC`,
    [String(msg.from.id)]
  );
  if (!rows.length) return bot.sendMessage(msg.chat.id, 'Kolleksiyangiz hozircha bo‘sh.');
  const lines = rows.map((r, i) => `${i + 1}. ${r.name} — ${r.anime} [${r.rarity}]`);
  bot.sendMessage(msg.chat.id, `🎴 Kolleksiyangiz (${rows.length}):\n${lines.join('\n')}`);
});
bot.onText(/^\/profile(?:@\w+)?$/, async msg => {
  await ensureUser(msg.from);
  const s = await get('SELECT * FROM user_stats WHERE user_id=?', [String(msg.from.id)]);
  const count = await get('SELECT COUNT(*) AS n FROM collections WHERE user_id=?', [String(msg.from.id)]);
  bot.sendMessage(msg.chat.id,
    `👤 ${displayName(msg.from)}\nXabarlar: ${s.messages}\nTo‘g‘ri topishlar: ${s.correct_guesses}\nKolleksiya: ${count.n} ta`
  );
});
bot.onText(/^\/rank(?:@\w+)?$/, async msg => {
  const rows = await all(
    `SELECT u.user_id, u.username, u.first_name, COUNT(c.character_id) AS total
     FROM user_stats u LEFT JOIN collections c ON c.user_id=u.user_id
     GROUP BY u.user_id ORDER BY total DESC, u.correct_guesses DESC LIMIT 10`
  );
  if (!rows.length) return bot.sendMessage(msg.chat.id, 'Reyting hozircha bo‘sh.');
  const lines = rows.map((r, i) => `${i + 1}. ${r.username ? '@' + r.username : (r.first_name || r.user_id)} — ${r.total}`);
  bot.sendMessage(msg.chat.id, `🏆 TOP 10:\n${lines.join('\n')}`);
});

bot.on('message', async msg => {
  try {
    if (!msg.from || msg.from.is_bot) return;
    await ensureUser(msg.from);

    // Check guesses against the active drop in groups and private chats.
    if (msg.text && !msg.text.startsWith('/')) {
      const active = await get('SELECT character_id FROM active_drops WHERE chat_id=?', [String(msg.chat.id)]);
      if (active) {
        const character = await get('SELECT * FROM characters WHERE id=?', [active.character_id]);
        if (character) {
          const guesses = [character.name, ...(character.aliases || '').split(',')].map(x => x.trim().toLowerCase()).filter(Boolean);
          if (guesses.includes(msg.text.trim().toLowerCase())) {
            const added = await addToCollection(msg.from, character);
            await run('DELETE FROM active_drops WHERE chat_id=?', [String(msg.chat.id)]);
            await bot.sendMessage(msg.chat.id,
              added ? `🎉 To‘g‘ri! ${character.name} kolleksiyangizga qo‘shildi! (${character.rarity})`
                    : `To‘g‘ri! ${character.name} sizda avvaldan bor edi.`
            );
          }
        }
      }
    }

    // Count only non-command group/supergroup messages.
    if ((msg.chat.type === 'group' || msg.chat.type === 'supergroup') && msg.text && !msg.text.startsWith('/')) {
      await run('UPDATE user_stats SET messages=messages+1 WHERE user_id=?', [String(msg.from.id)]);
      await run(
        `INSERT INTO group_stats(chat_id, message_count) VALUES(?,1)
         ON CONFLICT(chat_id) DO UPDATE SET message_count=message_count+1`,
        [String(msg.chat.id)]
      );
      const stats = await get('SELECT message_count FROM group_stats WHERE chat_id=?', [String(msg.chat.id)]);
      if (stats && stats.message_count >= 50) {
        await run('UPDATE group_stats SET message_count=0 WHERE chat_id=?', [String(msg.chat.id)]);
        await sendDrop(msg.chat.id);
      }
    }
  } catch (e) {
    console.error('message handler error:', e);
  }
});

bot.on('polling_error', err => console.error('Telegram polling error:', err.message));
bot.on('error', err => console.error('Bot error:', err.message));

init().then(() => console.log('Uzbek Waifu Bot ishga tushdi!'))
  .catch(err => {
    console.error('Database initialization failed:', err);
    process.exit(1);
  });

process.once('SIGINT', () => bot.stopPolling().finally(() => process.exit(0)));
process.once('SIGTERM', () => bot.stopPolling().finally(() => process.exit(0)));
